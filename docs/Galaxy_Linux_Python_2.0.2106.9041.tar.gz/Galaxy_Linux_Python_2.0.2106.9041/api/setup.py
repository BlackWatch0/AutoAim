#!/usr/bin/env python
# -*- coding:utf-8 -*-
from __future__ import print_function
from setuptools import setup, find_packages
import sys

setup(
    name='gxipy',
    version='2.0.2105.9261',
    description='',
    license='MIT',
    packages=['gxipy'],
)
